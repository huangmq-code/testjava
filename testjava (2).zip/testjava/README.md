``` 
docker build -t helloworld .  
docker run -d --name hellworld -p 8080:8080 helloworld
```
